#!/usr/bin/env python
import rospy
import time
from geometry_msgs.msg import PoseWithCovarianceStamped
from tf_conversions import transformations
from math import pi
from std_msgs.msg import String
import re
words_to_find = ["one", "two", "kitchen","hall","office"]
word_to_coordinates = {
    "one": (10.2, 1.73, 0.0),
    "two": (16.2, -1.73, 180.0),
    "kitchen": (10.2, 1.73, 180.0),
    "hall": (5.01,4.32,180.0),
    "office": (5.01,4.32,180.0),
    }

def listener():
    rospy.init_node('pub_goal', anonymous=True)

    rospy.Subscriber("/speech_result", String, callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

def callback(data):
    global words_to_find, word_to_coordinates
    sentence = data.data

    result = extract_words(words_to_find, sentence)
    print(result) 

    goals = []
    for word in result:
        word_lower = word.lower() 
        if word_lower in word_to_coordinates:
            goals.append(word_to_coordinates[word_lower])

    print(goals)
    if goals:
        publish_goals(goals)  # Call the function to publish goals



def publish_goals(goals):
    # Create a ROS publisher on the '/goal_pose' topic
    pub = rospy.Publisher('/goal_pose', PoseWithCovarianceStamped, queue_size=10)

    # Iterate through the list of goals
    for goal in goals:
        x, y, yaw_degree = goal  # Unpack the goal's x, y, and yaw values

        # Convert yaw from degrees to radians
        yaw = yaw_degree * pi / 180.0  

        # Create a PoseWithCovarianceStamped message
        goal_pose = PoseWithCovarianceStamped()
        goal_pose.header.stamp = rospy.Time.now()  # Set the current time
        goal_pose.header.frame_id = "map"  # Set the frame ID to "map"
        goal_pose.pose.pose.position.x = x  # Set x position
        goal_pose.pose.pose.position.y = y  # Set y position

        # Convert yaw to a quaternion and set it in the message
        q = transformations.quaternion_from_euler(0, 0, yaw)
        goal_pose.pose.pose.orientation.x = q[0]
        goal_pose.pose.pose.orientation.y = q[1]
        goal_pose.pose.pose.orientation.z = q[2]
        goal_pose.pose.pose.orientation.w = q[3]

        # Publish the goal pose
        pub.publish(goal_pose)
        rospy.loginfo("Published goal pose: x=%f, y=%f, yaw=%f degrees" % (x, y, yaw_degree))
        time.sleep(1)  # Wait for 1 second before publishing the next goal

def extract_words(words, string):
    pattern = r'\b(' + '|'.join(map(re.escape, words)) + r')\b'
    matches = re.findall(pattern, string, re.IGNORECASE)
    return matches

# Main execution block
if __name__ == '__main__':
    listener()